<?php

class Prato {

	public $codigo;
	public $nome;
	public $quantidadePessoasServidas;
	public $preco;

	function __construct( $codigo, $nome, $quantidadePessoasServidas, $preco) {
			
		$this->codigo = $codigo;	
		$this -> nome = $nome;
		$this -> quantidadePessoasServidas = $quantidadePessoasServidas;
		$this -> preco = $preco;
	}
		
	function getCodigo(){
		return $this->codigo;
	}

	function getNome() {
		return $this -> nome;
	}

	function getQuantidadePessoasServidas() {
		return $this -> quantidadePessoasServidas;
	}

	function getPreco() {
		return $this -> preco;
	}

	function setCodigo($valor){
			$this->codigo = $valor;
	}

	function setNome($valor) {
		$this -> nome = $valor;
	}

	function setQuantidadePessoasServidas($valor) {
		$this -> quantidadePessoasServidas = $valor;
	}

	function setPreco($valor) {
		$this -> preco = $valor;
	}
}
?>