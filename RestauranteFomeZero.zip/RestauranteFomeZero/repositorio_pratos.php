<?php
    require 'conexao.php';
	include 'prato.php';
 	include 'irepositorio_prato.php';
	
	//Classe de repositório de pratos que implementa IRepositorioPratos
	class RepositorioPratos implements IRepositorioPrato {
		
		//Objeto conexão que guardará a conexão com o banco
		private $conexao;
		
		//Construtor do repositório de pratos
		public function __construct()
		{
			//Cria o objeto conexão que será responsável pelas chamadas ao banco de dados
			$this->conexao = new Conexao("127.0.0.1", "root", "", "restaurantefomezero");
			
			//Conecta ao banco de dados
			if ($this->conexao->conectar() == false) {
				echo "Erro".mysqli_error();
			}
		}
		
		//Cadastra um novo prato. Observe que a SQL é preparada e enviada para o banco. 
		//O mesmo ocorre com o restante dos métodos dessa classe
		public function cadastrarPrato($prato)
		{
			$nome = $prato->getNome();
			$quantidadePessoasServidas = $prato->getQuantidadePessoasServidas();
			$preco = $prato->getPreco();
			
			$sql = "INSERT INTO prato (codigo, nome, quantidadePessoasServidas, preco) VALUES
			(NULL, '$nome', '$quantidadePessoasServidas', '$preco')";
			
			$this->conexao->executarQuery($sql);
		}
		
		//Remove um prato do banco de dados
		public function removerPrato($codigo)
		{
			$sql = "DELETE FROM prato WHERE codigo = '$codigo'";
			$this->conexao->executarQuery($sql);
		}
		
		//Atualiza a informação de um dado prato no banco de dados
		public function alterarPrato($prato)
		{
			$codigo = $prato->getCodigo();
			$nome = $prato->getNome();
			$quantidadePessoasServidas = $prato->getQuantidadePessoasServidas();
			$preco = $prato->getPreco();
			
			$sql = "UPDATE prato SET nome='$nome', 
			quantidadePessoasServidas='$quantidadePessoasServidas', preco='$preco'
			WHERE codigo='$codigo'";
			
			$this->conexao->executarQuery($sql);
		}
		
		//Busca um novo prato a partir de seu código. 
		//Observe que um novo objeto prato é criado baseado com o que é retornado do banco.
		public function buscarPrato($codigo)
		{
			//Obtem o primeiro registro do select abaixo
			$linha = $this->conexao->obtemPrimeiroRegistroQuery("SELECT * FROM prato WHERE codigo='$codigo'");
			 
			 //Cria um novo objeto prato baseado na busca acima
			 $prato = new Prato($linha['codigo'], $linha['nome'], $linha['quantidadePessoasServidas'], $linha['preco']);
			 
			 return $prato;
		}
		
		public function getListaPrato()
		{
			//Obtem a lista de todos os pratos cadastrados
			$listagem = $this->conexao->executarQuery("SELECT * FROM prato");
			
			//Cria um novo array onde os objetos pratos serão guardados
			$arrayPratos = array();
			
			//Varre a lista de entradas da tabela pratos e cria um novo objeto prato para cada entrada da tabela
			while($linha = mysqli_fetch_array($listagem)){
				
				$prato = new Prato($linha['codigo'], $linha['nome'], $linha['quantidadePessoasServidas'], $linha['preco']);
			    array_push($arrayPratos, $prato);
			}
			
			//Retorna o array de pratos
			return $arrayPratos;
		}
	} 

	//Cria o objeto repositório de pratos. Esse objeto será acessado pelo restante da aplicação para receber 
	//e enviar objetos pratos ao banco de dados.
	$repositorio = new RepositorioPratos();
	
?>