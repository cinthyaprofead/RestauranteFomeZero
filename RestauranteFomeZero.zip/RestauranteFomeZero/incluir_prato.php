<?php
   require 'repositorio_pratos.php';
   
   //Cria um novo objeto com os dados recebidos pelo form
   $pratoRecebido = new Prato(null, $_REQUEST['nome'], $_REQUEST['quantidadePessoasServidas'], $_REQUEST['preco']);
   
   //Envia para o repositorio
   $repositorio->cadastrarPrato($pratoRecebido);
   
   header('Location: index.php');
   exit;
?>

