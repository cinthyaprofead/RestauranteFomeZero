
CREATE DATABASE restaurantefomezero;

DROP TABLE IF EXISTS prato;

CREATE TABLE prato (
  codigo int(11) NOT NULL AUTO_INCREMENT,
  nome varchar(45) NOT NULL,
  quantidadePessoasServidas int(2) NOT NULL,
  preco varchar(45) NOT NULL,
  PRIMARY KEY (codigo)
);

INSERT INTO prato (codigo, nome, quantidadePessoasServidas, preco) VALUES (NULL, 'Galinha à Cabidela', '2', '52,35');
INSERT INTO prato (codigo, nome, quantidadePessoasServidas, preco) VALUES (NULL, 'Cozido', '2', '44,27');
INSERT INTO prato (codigo, nome, quantidadePessoasServidas, preco) VALUES (NULL, 'Feijoada', '4', '69,99');
INSERT INTO prato (codigo, nome, quantidadePessoasServidas, preco) VALUES (NULL, 'Carne de Sol', '3', '24,99');

