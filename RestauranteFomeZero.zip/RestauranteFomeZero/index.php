<?php
 	 //Cria um objeto repositório e inclui as classes básicas 
     require 'repositorio_pratos.php'; 
	 
     //Obtem a lista de todos os pratos cadastrados 
     $pratos = $repositorio->getListaPrato();
	 
	 //A variável $destino aponta para onde vamos enviar os dados do formulário.
	 //Inicialmente vai para incluir_prato.php
	 $destino = "incluir_prato.php";
	
	  // Se recebermos uma variável codigo pelo metodo GET faça o seguinte
	 if(isset($_GET['codigo'])){
	 	$codigo = $_GET['codigo']; //Guardamos o codigo enviado na variável $codigo
	 	//Obtemos o objeto prato relativo ao código
	 	$prato = $repositorio->buscarPrato($codigo);
		//Agora avariável destino vai apontar para alterar_prato.php
		$destino = "alterar_prato.php";
		//Vamos acrescentar este campo oculto no formulário que contem o codigo do resgistro
		$oculto = '<input type="hidden" name="codigo" value="'. $codigo .'" />';  
	 }
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title>Restaurante Fome Zero</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<link href="css/styles.css" rel="stylesheet">
	</head>
	<body>
<div class="wrapper">
    <div class="box">
        <div class="row">
        	
        	
            <!-- sidebar -->
            <div class="column col-sm-3" id="sidebar">
                <a class="logo" href="#"><span>Restaurante Fome Zero</span></a>
                <ul class="nav">
                    <li class="active">
                    	<a href="index.php">Prato Principal</a>
                    </li>
                    <li>
                    	<a href="index.php">Prato Promocional</a>
                    </li>
                    <li>
                    	<a href="index.php">Sobremesa</a>
                    </li>
                </ul>
                
            </div>
            <!-- /sidebar -->
          
            <!-- main -->
            <div class="column col-sm-9" id="main">
                <div class="padding">
                    <div class="full col-sm-9">
                      
                        <!-- content -->
                        <div class="col-sm-12" id="featured">   
                          <div class="page-header text-muted">Restaurante Fome Zero</div>
                          
                          <form class="form-horizontal" action="<?=$destino; ?>" method="post"> 
                          	<?= @$oculto; ?>
							<fieldset>
							
							<legend>Cadastrar/Alterar Prato</legend>
							
							<div class="control-group">
							  <label class="control-label" for="prato">Nome</label>
							  <div class="controls">
							    <input id="nome" name="nome" type="text" 
							     value="<?php echo isset($prato)?$prato->getNome():""; ?>" placeholder="" class="input-xxlarge" />
							    
							  </div>
							</div>
							
							<div class="control-group">
							  <label class="control-label" for="sinopse">Quantidade de Pessoas Servidas</label>
							  <div class="controls" >                     
							    
							    <input id="quantidadePessoasServidas" name="quantidadePessoasServidas" type="text" 
							    value="<?php echo isset($prato)?$prato->getQuantidadePessoasServidas():"";  ?>" placeholder="" class="input-xxlarge"> 
							  </div>
							</div>
							
							<!-- Text input-->
							<div class="control-group">
							  <label class="control-label" for="quantidade">Preço (R$)</label>
							  <div class="controls">
							    <input id="preco" name="preco" type="text" 
							    value="<?php echo isset($prato)?$prato->getPreco():"";  ?>" placeholder="" class="input-xxlarge">
							    
							  </div>
							</div>
	
							<!-- Button -->
							<div class="control-group">
							  <label class="control-label" for=""></label>
							  <div class="controls">
							    <input type="submit" class="btn btn-danger" value="Salvar" />
							    
							  </div>
							</div>
							
							</fieldset>
							</form>
                        </div>
                        
                        <!--/top story-->

                        
                        <div class="col-sm-12" id="stories">  
                          <div class="page-header text-muted divider">
                            Pratos Cadastrados
                          </div>
                        </div>
                        
                        <table class="table table-hover">
                        	
                        	
                        	<!--Lista de Pratos no banco -->
                        	
                        	<?php
                        		while($pratoTemporario = array_shift($pratos)){                               
								
								?> 
						<tr>
					       <td class="col-md-6"> <?php echo $pratoTemporario->getNome() ?> </td> 
					       <td class="col-md-1"><a class="btn btn-danger" href="index.php?codigo=<?= $pratoTemporario->getCodigo(); ?>" role="button">Alterar</a></td>
					       <td class="col-md-1"><a class="btn btn-danger" href="remover_prato.php?codigo=<?= $pratoTemporario->getCodigo(); ?>" role="button">Remover</a></td> 
					  </tr> 
							<?php                
							}               
							?>
                        	
						</table>

                    </div><!-- /col-9 -->
                </div><!-- /padding -->
            </div>
            <!-- /main -->
          
          
          
        </div>
    </div>
</div>
	<!-- script references -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</body>
</html>