<?php
   require 'repositorio_pratos.php';
   
   //Cria um novo objeto com as entradas recebidas pelo usuário
   $pratoRecebido = new Prato($_REQUEST['codigo'], $_REQUEST['nome'], $_REQUEST['quantidadePessoasServidas'], $_REQUEST['preco']);
   
   //Atualiza o prato existente no banco com os dados recebidos pelo form
   $repositorio->alterarPrato($pratoRecebido);
   
   header('Location: index.php');
   exit;
?>

