<?php
	require 'repositorio_pratos.php';
	
	$repositorio->removerPrato($_REQUEST['codigo']);

	header('Location: index.php');
    exit;
?>

