<?php
    
    //Interface de repositorio para pratos. 
	interface IRepositorioPrato{
		public function cadastrarPrato($prato);
		public function removerPrato($codigo);
		public function alterarPrato($prato);
		public function buscarPrato($codigo);
		public function getListaPrato();
	}
?>


